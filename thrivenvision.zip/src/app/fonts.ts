import { Exo, Kaushan_Script } from "next/font/google";

export const exo = Exo({ subsets: ["latin"] });
export const kaushanScript = Kaushan_Script({
  subsets: ["latin"],
  weight: "400",
});
