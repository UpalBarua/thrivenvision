import { getAllTrustedCompany } from "@/lib/services";
import { Button } from "@nextui-org/react";
import { ChevronRight } from "lucide-react";
import ExportedImage from "next-image-export-optimizer";
import { SectionHeading } from "./ui/section-heading";
import { SectionSubheading } from "./ui/section-subheading";

export async function TrustedCompanies() {
  // const companines = await getAllTrustedCompany();
  const companines = [
    "/images/logos/logo-0.png",
    "/images/logos/logo-1.png",
    "/images/logos/logo-2.png",
    "/images/logos/logo-3.png",
    "/images/logos/logo-4.png",
    "/images/logos/logo-5.png",
    "/images/logos/logo-6.png",
    "/images/logos/logo-7.png",
    "/images/logos/logo-8.png",
  ];

  return (
    <section className="grid grid-cols-1 items-center gap-10 pb-20 pt-10 lg:grid-cols-2">
      <div className="order-last flex flex-col items-start lg:order-first">
        <SectionHeading className="text-start">
          Partnering with
          <br />
          Industry Leaders
        </SectionHeading>
        <SectionSubheading className="px-0 pb-8 text-start">
          Our agency is a hub for elite partnerships, trusted by over a hundred
          leading brands to deliver impactful and innovative collaborations.
          Discover the synergy of creativity and strategy in our portfolio of
          successful projects.
        </SectionSubheading>
        <Button
          color="primary"
          size="lg"
          endContent={<ChevronRight />}
          className="gradient-btn text-base font-semibold"
        >
          <span>Lets Connect</span>
        </Button>
      </div>
      <div className="grid grid-cols-3 gap-8 lg:gap-4">
        {companines?.map((company) => (
          <div
            key={company}
            className="flex place-content-center rounded-xl border border-foreground/10 p-0 sm:bg-background/80 lg:p-6"
          >
            <ExportedImage
              src={company}
              alt="trusted company"
              height={80}
              width={200}
              className="object-fit object-center"
              priority
              // quality={95}
            />
          </div>
        ))}
      </div>
    </section>
  );
}
